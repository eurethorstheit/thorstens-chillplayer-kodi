#!/bin/bash

quelle=/home/thorsten/Dokumente/Programmierung/Kodi/plugin.chillthorsten.video
ziel=/home/thorsten/.kodi/addons/plugin.chillthorsten.video

rsync -av --delete $quelle $ziel

