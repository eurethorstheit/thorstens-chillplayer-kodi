#!/bin/bash

quelle=/home/thorsten/Dokumente/Programmierung/Kodi/plugin.video.chillthorsten
ziel=/home/thorsten/.kodi/addons/

cp -r $quelle $ziel

